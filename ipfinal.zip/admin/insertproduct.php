
<!DOCTYPE html>
<?php
include("includes/db.php");
?>
<html>
<head>
	<title>Insert product</title>
</head>
<body>
<form action="insertproduct.php" method="post" enctype="multipart/form-data">
	<table align="center" width="1000">
		<tr align="center" >
			<th colspan="6"><h2 >Insert New Product </h2></th>
		</tr>
		<tr>
			<td align="center"><b> Product Title</b></td>
			<td> <input type="text" name="product_title" required /></td>
		</tr>
		<tr>
			<td align="center"><b> Product category</b></td>
			<td> <select name="product_cat" required>
				<option >Select a Category</option>
				<?php 
				$cat_query = "select * from category";
				$cat_run = mysqli_query($con, $cat_query);
				while ($row_table = mysqli_fetch_array($cat_run)) {
					$cat_id = $row_table['cat_id'];
					$cat_title = $row_table['cat_title'];

					echo "<option>$cat_title</option>";
					
					}

				?>
			 </td>
		</tr>
		<tr>
			<td align="center"><b> Product price</b></td>
			<td> <input type="text" name="product_price" required /></td>
		</tr>
		<tr>
			<td align="center"><b> Product Image</b></td>
			<td> <input type="file" name="product_image" required /></td>
		</tr>
		<tr align="center">
			<td colspan="8"><input type="submit" name="insert_product" value="insert product"></td>
		</tr>
</form>

</body>
</html>
<?php
	if(isset($_POST['insert_product']))
	{
		$product_title = $_POST['product_title'];
		$product_cat = $_POST['product_cat'];
		$product_price = $_POST['product_price'];
		
		$product_image = $_FILES['product_image']['name'];
		$product_image_tmp = $_FILES['product_image']['tmp_name'];

		move_uploaded_file($product_image_tmp, "product_images/$product_image");
		$insertproduct = "insert into products (product_name, product_cat, product_price, product_image) values('$product_title','$product_cat','$product_price','$product_image')";
		$insert_pro = mysqli_query($con, $insertproduct);

		if($insert_pro)
		{
			echo "<script>alert('Product has been added in database.')</script>";
			echo "<script>window.open('insertproduct.php','_self')</script>";
		}

	}


?>