<?php
$con = mysqli_connect("localhost","id7535528_root","r987654321","id7535528_ecommerce");

?>