<?php
include("admin/includes/db.php");
?>
<html>
<head>

<meta name="viewport" content="width=device-width, initial-scale=1">
	<link type="text/css" href="main.css" rel="stylesheet" >
    <link type="text/css" href="main1.css" rel="stylesheet" >
     <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <style>

    </style>
	<title>ARF-medical</title>
</head>
<body  >
	<header>
        <nav id="navbar" >
        <div  class="dropdown" >
            <div class="menubar">
         <div class="content">
        <div class="menu"></div>
        <div class="menu"></div>
             <div class="menu"></div>
             
             </div>
             </div>
            
    <div class="dropdown-content">
        <div>
        <a href="main1.html">Home&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
        <br><br>
        <div>
        <a href="main1.html">My profile&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
        <br>
        <div>
        <a href="main1.html">My Orders&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
        <br>
        <div>
        <a href="main1.html">Upload prescriptions</a>
            </div>
        <br>
        <div>
        <a href="main1.html">my wallet&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
        <br><br>
        <div>
        <a href="main1.html">call us&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
        <br>
        <div>
        <a href="main1.html">Logout&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
            </div>
    </div>
            </div>
       	<div  class="dropdown" >
        	<a href="index.html" class="home" class="dropbtn">Home</a>
            </div>
		<div  class="dropdown" >
        	<a href="category.php" class="home" class="dropbtn" >Buy Online</a>
            </div>
            <div  class="dropdown" >
        	<a href="services/service.html" class="home" class="dropbtn">services</a>
            </div>
            <div class="dropdown">
        	<a href="contect.html" class="home" class="dropbtn">Contact Us</a>
        </div>
        <div class="dropdown">
        	<a href="faq.html" class="home" class="dropbtn">FAQ</a>
        </div>
        <div class="dropdown">
        	<a href="#" class="home" class="dropbtn">About</a>
        </div>
            
           <form action="home.php" class="search-container">
      <input type="text" placeholder="Search.." name="search">
      <input type="submit" value="search"></input>
    </form>

                                                                                               
    <div class="logo">
        <li><a href="#"><img src="logo1.PNG"  alt="Medicare logo" width="100%" height="100%"></a></li>
    </div>
        </nav>
    </header>
    <script>
    function chkData()
{
var nm = document.frm.user.value;


if (nm=="")
{
alert("please enter name");
return false
}
}
</script>
    <table height="100%" width="100%" class="table">
    <td class="leftnav">
        <div class="card" >
            <div class="option1">
            <form name="frm" action="login.php" method="post">
            <img src="profile.png" class="profile">
            <h1>Login Here</h1>
            <p>Username</p>
            <input type="text" id="user" name="user" placeholder="Enter Username" required>
            <p>Password</p>
            <input type="password" id="pass" name="pass" placeholder="Enter Password" required>
            <br>
            <button type="submit" name="login"  onclick="chkData()" style="width: 100%; height: 10%; border: 1px solid ; background-color:lightcoral; color: white">Login</button>
            </form>
            
<button onclick="document.getElementById('id01').style.display='block'" style="width: 100%; height: 10%; border: 1px solid ; background-color:lightgreen; color: white">Register now</button>
            <br>
            <a href="forget.html">Forgot password or username.</a>
            
            </div>
        </div>
    </td>
    <td class="centernav">
       
            
        <a href="#"><img src="1.jpg" height="300px"  >
            <p class="imgtext"><marquee>Offer! Offer! 100% off Offer! Offer!</marquee></p></a>
            
        <a href="#"><img src="3.jpg"  height="600px"></a>
        <a href="#"><img src="thermometer-1539191__340.jpg"  height="600px"></a>
        <a href="#"><img src="5.jpg"  height="600px"></a>
        
    </td>
    <script>
//for registration page validation
function chkRegisteration()
{
var first= document.frm1.user_fname.value;
var second= document.frm1.user_sname.value;
var no= document.frm1.user_ph.value;
var adhaar= document.frm1.user_adh.value;
var email= document.frm1.user_email.value;
var nm= document.frm1.user_name.value;
var pw1= document.frm1.user_pass.value;
var pw2= document.frm1.user_repass.value;
var atpos= email.indexOf("@");
var dotpos= email.lastIndexOf(".");


if (first=="")
{
alert("please enter unique username");
return false
}
else if(second=="")
{
alert("please enter name unique sname");
return false;
}
else if(no.length<10 && no.length>10)
{
alert("mobile number should be 10 digit");
return false;
}
else if(adhaar.length<12 && adhaar.length>12)
{
alert("adhaar number should be 12 digit");
return false;
}
else if(atpos<1 || dotpos<atpos+2 || dotpos+2>=email.length)
{
alert("please enter valid e-mail address");
return false;
}
else if(nm=="")
{
alert("enter a name");
return false;
}

else if(pw1==pw2 )
{
return true;
}
else
{
alert("Both password should be same");
return false;
}
}
</script>
        <div id="id01" class="modal">
  
  <form name="frm1" class="modal-content animate" action="register.php" method="post">
      <div class="container" style="background-color:#f1f1f1">
    <div class="imgcontainer">
      <span onclick="document.getElementById('id01').style.display='none'" class="close" title="Close Modal">&times;</span>
      <img src="profile.png" alt="Avatar" class="avatar">
    <div class="container" style="background-color:#f1f1f1">
      <h1 class=".rh1">Register Here</h1>
        <p>First Name</p>
        <input  type="text" name="user_fname" placeholder="Enter First Name." required>
        <p>Second Name</p>
        <input type="text"   name="user_sname" placeholder="Enter Second Name" required>
          <p>Phone Number</p>
        <input type="text" name="user_ph" placeholder="Enter Phone Number" required>
          <p>Adhaar Number</p>
        <input type="text" name="user_adh" placeholder="Enter Adhaar number" required>
          <p>Email</p>
        <input type="email" name="user_email" placeholder="Enter Email" required>
          <p>Username</p>
        <input type="text" name="user_name" placeholder="Enter Username" required>
          <p>Password</p>
        <input type="password" name="user_pass" placeholder="Enter password" required>
            <p>Re-enter password</p>
        <input type="password" name="user_repass" placeholder="Re-enter password" required>
        
      <button type="submit" name="insert_new"  onclick="chkRegisteration()" style="width: 100%; height: 5%; border: 1px solid ; background-color:lightgreen; color: white">Register</button>
        <br>
      <label>
        <input type="checkbox" checked="checked" name="remember"> Remember me
      </label>
      <button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn">Cancel</button>
    </div>
      </div>
      </div>
  </form>
</div>

        
    </table>
    <div class="footer">
    <div class="card4">
    <h1>E medical</h1>
  <p class="title">The shop which you can trust</p>
  <p>Mumbai</p>
  <div style="margin: 24px 0;">
    <a href="#"><i class="fa fa-dribbble"></i></a> 
    <a href="#"><i class="fa fa-twitter"></i></a>  
    <a href="#"><i class="fa fa-linkedin"></i></a>  
    <a href="#"><i class="fa fa-facebook"></i></a> 
 </div>
 <p><button>Contact</button></p>
</div>
    </div>

    </body>
    <script>
window.onscroll = function() {myFunction()};

var navbar = document.getElementById("navbar");
var sticky = navbar.offsetTop;
var modal = document.getElementById('id01');
function myFunction() {
  if (window.pageYOffset >= sticky) {
    navbar.classList.add("sticky")
  } else {
    navbar.classList.remove("sticky");
  }
}
        window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
</html>



